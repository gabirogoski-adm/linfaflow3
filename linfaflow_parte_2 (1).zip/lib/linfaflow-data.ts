export const HERO_FIRST_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Linfaflow__leveza_e_bem-estar_nos_detalhes.png?v=1794834010"
export const SECOND_THUMB_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/2_foto_miniatura.webp?v=1794605268"
export const THIRD_THUMB_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/629fd19e-ea19-42bb-acfd-572ee44e7b62.png?v=1794843499"
export const FOURTH_THUMB_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/0274a758-065a-4c4f-a504-5ad201cfbf9b.png?v=1794843816"
export const DR_CICERO_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c4dcd2f4-d36f-4c20-a49d-065b9912f5bc.png?v=1794843487"
export const COMPARE_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/0274a758-065a-4c4f-a504-5ad201cfbf9b.png?v=1794843816"
export const HYDRATION_IMAGE = "/images/hydration-cleanse.gif"
export const GUARANTEE_BF_IMAGE = "/images/generated/linfaflow_garantia_bf_1794837805164.jpg"
export const STICKY_PRODUCT_IMAGE = "/images/sticky-product.png"
export const GUARANTEE_CUSTOMER_IMAGE =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/087d329b-03ee-4b7a-9c08-95f264b83dec.png?v=1794840649"

const DELIVERY_PHOTOS = [
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/26.png?v=1794839697",
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/28.png?v=1794839697",
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/27.png?v=1794839698",
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/25.png?v=1794839697",
]

export const RITUAL_IMAGES = {
  scoop:
    "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/57c91933-a084-405e-807b-6008c4ae128b.webp?v=1794605384",
  water:
    "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/ae6326c0-48f7-4c46-b8c6-071f8f9bfebd.webp?v=1794605384",
  sleep:
    "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/f0ad1b51-14dd-46f4-b965-709515949fc1.webp?v=1794605384",
}

export const KIT_IMAGES = {
  "1": "/images/kits/kit-1.png",
  "3": "/images/kits/kit-3.png",
  "5": "/images/kits/kit-5.png",
} as const

export const keywords = [
  "BARRIGA DESINCHADA EM 14 DIAS",
  "ROSTO DEFINIDO EM 14 DIAS",
  "PERNAS LEVES EM 14 DIAS",
  "DRENAGEM LINFÁTICA NATURAL",
  "ELIMINAÇÃO DE LÍQUIDOS RETIDOS",
  "DESESTUFA O ABDÔMEN",
  "ACELERA O METABOLISMO E QUEIMA GORDURA",
  "AÇÃO ANTI-INFLAMATÓRIA E IMUNIDADE",
  "4 EXTRATOS VEGETAIS",
  "REGULARIZADO NA ANVISA",
  "FRETE GRÁTIS",
  "GARANTIA DE 90 DIAS",
  "VEGANO · SEM GLÚTEN · SEM AÇÚCAR",
]

export const benefits = [
  "Barriga desinchada, rosto definido e pernas leves em 14 dias",
  "Ativa a drenagem linfática e seca líquidos retidos",
  "Acelera o gasto calórico e desestufa o abdômen",
  "Em pó solúvel para fazer você beber mais água",
  "Sabor neutro · dissolve em segundos",
  "150 g por pote · garantia de 90 dias",
]

export const quizQuestions = [
  {
    area: "Inchaço",
    short: "Olhos e rosto inchados",
    question: "Você acorda com o rosto ou os olhos visivelmente inchados?",
    image: "/images/quiz/quiz-rosto.png",
    imageAlt: "Rosto em close com pálpebras e bolsas sob os olhos visivelmente inchadas",
  },
  {
    area: "Inchaço",
    short: "Barriga estufada",
    question: "Sua barriga fica visivelmente estufada e a roupa aperta ao longo do dia?",
    image: "/images/quiz/quiz-abdomen.png",
    imageAlt: "Abdômen estufado indicando retenção de líquidos",
  },
  {
    area: "Circulação",
    short: "Pernas pesadas",
    question: "Suas pernas ficam inchadas e pesadas depois de um dia em pé?",
    image: "/images/quiz/quiz-pernas.png",
    imageAlt: "Pernas com inchaço visível nas panturrilhas e nos tornozelos",
  },
  {
    area: "Inchaço",
    short: "Marca da meia na pele",
    question: "Você percebe o tornozelo inchado ou a meia deixa uma marca funda na pele?",
    image: "/images/quiz/quiz-marcas.png",
    imageAlt: "Close de tornozelo inchado com uma marca funda deixada pela meia",
  },
  {
    area: "Circulação",
    short: "Muitas horas sentada(o)",
    question: "Depois de muitas horas sentada(o) ou em pé, seus tornozelos ficam inchados?",
    image: "/images/quiz/quiz-rotina.png",
    imageAlt: "Pessoa sentada por longas horas com retenção nas extremidades",
  },
  {
    area: "Inchaço",
    short: "Roupa apertando à noite",
    question: "À noite, a barriga estufada faz a roupa apertar na cintura?",
    image: "/images/quiz/quiz-roupa.png",
    imageAlt: "Pessoa com o cós do jeans apertado sobre a barriga",
  },
  {
    area: "Circulação",
    short: "Sapatos apertados",
    question: "No fim do dia, seus pés incham e os sapatos ficam apertados?",
    image: "/images/quiz/quiz-leveza.png",
    imageAlt: "Pés inchados pressionando as tiras e o cabedal de sapatos apertados",
  },
]

export const liquidFlowSteps = [
  {
    step: "1",
    title: "O corpo desacelera",
    text: "Muito tempo sentado, calor, sal a mais, hormônios e noite mal dormida deixam esse fluxo lento.",
    image: "/images/generated/liquid_slowdown_1794837140571.jpg",
    imageAlt: "Rotina com muitas horas sentado que desacelera a circulação",
  },
  {
    step: "2",
    title: "O líquido fica parado",
    text: "E se acumula onde tem espaço: rosto ao acordar, barriga à noite, pernas no fim do dia. Parece gordura, mas é água.",
    image: "/images/generated/liquid_trapped_1794837140363.jpg",
    imageAlt: "Acúmulo de líquidos retidos no abdômen e nas pernas",
  },
  {
    step: "3",
    title: "O líquido volta a se mover",
    text: "LinfaFlow contém 4 extratos vegetais que ativam a drenagem natural e fazem o corpo eliminar o que estava parado — entregando barriga desinchada, rosto definido e pernas leves em 14 dias.",
    image: "/images/generated/liquid_moving_1794837141887.jpg",
    imageAlt: "Bebida com extratos vegetais em movimento na água",
  },
]

export const ritualSteps = [
  {
    title: "Pegue 1 scoop",
    text: "Uma medida rasa do pó concentrado, uma vez por noite, para ativar a drenagem enquanto você descansa.",
    image: RITUAL_IMAGES.scoop,
    imageAlt: "Colher dosadora com pó solúvel LinfaFlow",
  },
  {
    title: "Misture em água",
    text: "Dissolva em 200 ml de água. O formato em pó é proposital: faz você beber mais água todos os dias para destravar e eliminar o líquido retido.",
    image: RITUAL_IMAGES.water,
    imageAlt: "Pó sendo misturado em um copo com água pura",
  },
  {
    title: "Beba antes de dormir",
    text: "Feche o dia hidratado(a) com os 4 extratos agindo para alcançar barriga desinchada, rosto definido e pernas leves em 14 dias — e continue tomando todos os dias para manter os resultados.",
    image: RITUAL_IMAGES.sleep,
    imageAlt: "Pessoa bebendo água antes de dormir em rotina noturna leve",
  },
]

export interface IngredientDetail {
  name: string
  focus: string
  image: string
  imageAlt: string
  parts: { text: string; bold?: boolean }[]
}

export const ingredients: IngredientDetail[] = [
  {
    name: "Chá Verde",
    focus: "Foco: Metabolismo Ativo e Equilíbrio Corporal",
    image: "/images/ingredients/green-tea.png",
    imageAlt: "Folhas frescas de chá verde",
    parts: [
      { text: "Auxilia na ativação do " },
      { text: "metabolismo energético", bold: true },
      { text: " e favorece a " },
      { text: "redução de medidas", bold: true },
      { text: " dentro da sua rotina diária, atuando com os outros extratos para um corpo mais leve em 14 dias." },
    ],
  },
  {
    name: "Hibisco",
    focus: "Foco: Drenagem Natural e Leveza Diária",
    image: "/images/ingredients/hibiscus.png",
    imageAlt: "Flores vermelhas de hibisco e pétalas secas",
    parts: [
      { text: "Com reconhecida ação de " },
      { text: "drenagem natural", bold: true },
      { text: ", ajuda a " },
      { text: "eliminar o excesso de líquidos", bold: true },
      { text: " acumulados entre os tecidos para trazer mais leveza ao rosto, barriga e pernas em 14 dias." },
    ],
  },
  {
    name: "Gengibre",
    focus: "Foco: Termogênese e Conforto Abdominal",
    image: "/images/ingredients/ginger.png",
    imageAlt: "Raiz fresca de gengibre fatiada",
    parts: [
      { text: "Contribui para a " },
      { text: "ativação circulatória", bold: true },
      { text: " e o " },
      { text: "conforto abdominal", bold: true },
      { text: ", ajudando a aliviar a sensação de estufamento ao longo do dia com sua ação natural." },
    ],
  },
  {
    name: "Chá Branco",
    focus: "Foco: Ação Antioxidante e Vitalidade",
    image: "/images/ingredients/white-tea.png",
    imageAlt: "Brotos e folhas nobres de chá branco",
    parts: [
      { text: "Rico em polifenóis que oferecem " },
      { text: "proteção antioxidante", bold: true },
      { text: " e fortalecem o " },
      { text: "equilíbrio imunológico", bold: true },
      { text: ", completando a fórmula para potencializar seus resultados de leveza e bem-estar em 14 dias." },
    ],
  },
]

export const trustPillars = [
  {
    title: "Regularizado na Anvisa",
    text: "Dentro das normas brasileiras",
  },
  {
    title: "Produzido no Brasil",
    text: "Qualidade controlada por lote",
  },
  {
    title: "Testado e aprovado",
    text: "+60.000 clientes satisfeitos",
  },
  {
    title: "Fórmula natural",
    text: "4 extratos de rápida absorção",
  },
]

export const trustAttributes = [
  {
    label: "Vegano",
    image: "/images/generated/trust_vegano_1794837141736.jpg",
  },
  {
    label: "Sem álcool",
    image: "/images/generated/trust_sem_alcool_1794837141055.jpg",
  },
  {
    label: "Sem glúten",
    image: "/images/generated/trust_sem_gluten_1794837141971.jpg",
  },
  {
    label: "Sem açúcar",
    image: "/images/generated/trust_sem_acucar_1794837142694.jpg",
  },
]

export const kits = [
  {
    id: "1",
    label: "1 unidade",
    name: "1 POTE",
    subtitle: "Tratamento 1 mês",
    unit: "119,90",
    total: "119,90",
    installments: "12x de R$ 12,04",
    daily: "R$ 3,99 por dia",
    save: null,
    image: KIT_IMAGES["1"],
    recommended: false,
  },
  {
    id: "3",
    label: "MAIS VENDIDO",
    name: "LEVE 3, PAGUE 2",
    subtitle: "Tratamento 3 meses · 1 pote grátis",
    unit: "79,93",
    total: "239,80",
    installments: "12x de R$ 24,00",
    daily: "R$ 2,66 por dia",
    save: "Economize R$ 119,90",
    image: KIT_IMAGES["3"],
    recommended: true,
  },
  {
    id: "5",
    label: "MAIOR ECONOMIA",
    name: "LEVE 5, PAGUE 3",
    subtitle: "Tratamento 5 meses · 2 potes grátis",
    unit: "71,94",
    total: "359,70",
    installments: "12x de R$ 36,11",
    daily: "R$ 2,39 por dia",
    save: "Economize R$ 239,80",
    image: KIT_IMAGES["5"],
    recommended: false,
  },
]

export const faqs = [
  {
    question: "Como preparo e tomo o LinfaFlow?",
    answer:
      "Misture 1 scoop raso em 200 ml de água, preferencialmente à noite antes de dormir. O sabor é neutro e dissolve rápido — além de ativar a drenagem, aumenta sua hidratação diária.",
  },
  {
    question: "Em quanto tempo consigo ver barriga desinchada, rosto definido e pernas leves?",
    answer:
      "Os 4 extratos agem juntos desde os primeiros dias para eliminar o líquido retido e desestufar o corpo. A maioria dos clientes relata barriga desinchada, rosto definido e pernas leves em 14 dias de uso contínuo. Para manter os resultados a longo prazo, é importante continuar utilizando o LinfaFlow diariamente.",
  },
  {
    question: "O LinfaFlow funciona mesmo se o inchaço parecer gordura?",
    answer:
      "Sim. Boa parte do volume abdominal e nas pernas vem de líquido retido entre os tecidos e inflamação. O combo seca a retenção hídrica, acelera o gasto calórico e reduz a absorção de gorduras.",
  },
  {
    question: "E se eu não gostar ou não notar resultado?",
    answer:
      "Você tem 90 dias de garantia incondicional. Se não perceber redução no inchaço e mais leveza no seu corpo, basta solicitar o reembolso dentro do prazo de 90 dias.",
  },
  {
    question: "Se o LinfaFlow funciona em 14 dias, por que devo tomar por mais tempo?",
    answer:
      "Para manter os resultados. Os primeiros 14 dias destravam a drenagem linfática e eliminam o excesso de líquido acumulado, mas fatores diários como sal, horas sentado(a), calor e rotina continuam favorecendo nova retenção. Ao continuar utilizando nos meses seguintes, você protege o equilíbrio do organismo e mantém a barriga desinchada, o rosto definido e as pernas leves sem efeito rebote.",
  },
  {
    question: "Quanto tempo leva para o pedido chegar?",
    answer:
      "O envio é imediato após a confirmação com frete grátis para todo o Brasil. Você acompanha o código de rastreio completo diretamente pelo seu e-mail e WhatsApp.",
  },
  {
    question: "Quem deve consultar um médico antes de usar?",
    answer:
      "Gestantes, lactantes e pessoas em uso contínuo de medicamentos específicos devem consultar seu profissional de saúde antes de iniciar qualquer suplemento.",
  },
]

export interface GoogleReview {
  nome: string
  inicial: string
  cor: string
  tempo: string
  estrelas: number
  texto: string
  avatar?: string
  photo?: string
  deliveryPhoto?: string
}

export const GOOGLE_RATING_SUMMARY = {
  nota: "4,9",
  total: "1.842",
}

export const HERO_REVIEWS: GoogleReview[] = [
  {
    nome: "Maria K.",
    inicial: "M",
    cor: "#7c3aed",
    tempo: "há 2 semanas",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/16.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/15.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[0],
    texto:
      "Acordava com o rosto inchado mesmo dormindo bem, tinha vergonha de me olhar no espelho de manhã. Em 2 semanas de LinfaFlow isso mudou. Foi uma bênção.",
  },
  {
    nome: "Renata M.",
    inicial: "R",
    cor: "#b45309",
    tempo: "há 3 semanas",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/14.png?v=1794839127",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/13.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[1],
    texto:
      "Já me falaram que era gordura, lipedema, celulite, idade... tudo menos retenção. Eu tinha me conformado. No terceiro mês de LinfaFlow minhas pernas afinaram visivelmente. Era líquido parado esse tempo todo.",
  },
  {
    nome: "Roberto S.",
    inicial: "R",
    cor: "#1b5e34",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_8.png?v=1794839449",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_7.png?v=1794839450",
    deliveryPhoto: DELIVERY_PHOTOS[2],
    texto:
      "Jurava que era gordura na barriga. 4 meses de LinfaFlow seguindo o protocolo, e a calça 48 que estava encostada voltou a fechar. Hoje uso 44 com folga.",
  },
]

export const GOOGLE_REVIEWS: GoogleReview[] = [
  {
    nome: "Camila F.",
    inicial: "C",
    cor: "#0369a1",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/12.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/11.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[3],
    texto:
      "Trabalho 9 horas sentada e minhas pernas chegavam em casa pesadas e marcadas pela meia. Em 14 dias tomando 1 scoop à noite em água, acordei com os tornozelos finos outra vez.",
  },
  {
    nome: "Juliana T.",
    inicial: "J",
    cor: "#be123c",
    tempo: "há 2 meses",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/10.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/9.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[0],
    texto:
      "Eu não conseguia beber água durante o dia. Como o LinfaFlow dissolve super rápido e não tem gosto forte, virou meu ritual da noite. Minha barriga desestufou absurdamente em 14 dias.",
  },
  {
    nome: "Patrícia L.",
    inicial: "P",
    cor: "#0f766e",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/8.png?v=1794839127",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/7.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[1],
    texto:
      "Sempre tive rosto redondo de manhã e bolsas embaixo dos olhos. Comprei o kit de 3 potes e com 14 dias minha pele e meu contorno facial já estavam totalmente definidos.",
  },
  {
    nome: "Fernanda A.",
    inicial: "F",
    cor: "#4338ca",
    tempo: "há 3 semanas",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/6.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/5.png?v=1794839127",
    deliveryPhoto: DELIVERY_PHOTOS[2],
    texto:
      "Meu vestido favorito não fechava nas costas por causa do estufamento da tarde. Depois que comecei o protocolo noturno, a diferença na cintura foi surreal.",
  },
  {
    nome: "Marcelo D.",
    inicial: "M",
    cor: "#15803d",
    tempo: "há 2 meses",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_2.png?v=1794839449",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem.png?v=1794839450",
    texto:
      "Minha esposa comprou e eu resolvi testar também porque ficava o dia inteiro de pé na loja. Em 10 dias já senti os pés menos inchados e muito mais disposição ao acordar.",
  },
  {
    nome: "Beatriz C.",
    inicial: "B",
    cor: "#a21caf",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/4.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/3.png?v=1794839127",
    texto:
      "Já tinha gastado dinheiro com vários chás prontos que não faziam nada. O combo chá verde, hibisco, gengibre e chá branco desse pó seco entrega exatamente o que promete.",
  },
  {
    nome: "Luciana V.",
    inicial: "L",
    cor: "#c2410c",
    tempo: "há 3 meses",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/2.png?v=1794839126",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/1_6d4d8832-39ba-4c30-9e54-f982d35dd9ca.png?v=1794839126",
    texto:
      "Acabou aquele sufoco de chegar à noite com a calça apertando a barriga. Perdi 4 cm de cintura só eliminando líquido parado nas primeiras duas semanas.",
  },
  {
    nome: "Eduardo M.",
    inicial: "E",
    cor: "#166534",
    tempo: "há 2 meses",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_6.png?v=1794839450",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_5.png?v=1794839450",
    texto:
      "Viajo muito de carro e meus tornozelos pareciam duas bolas no fim do dia. Agora não fico sem meu pote na mala.",
  },
  {
    nome: "Rodrigo H.",
    inicial: "R",
    cor: "#1e40af",
    tempo: "há 2 meses",
    estrelas: 5,
    avatar: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_4.png?v=1794839450",
    photo: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/homem_3.png?v=1794839451",
    texto:
      "Comprei o kit de 5 potes para dividir com minha esposa. Melhor custo-benefício e o resultado na barriga aparece mesmo.",
  },
  {
    nome: "Paula S.",
    inicial: "P",
    cor: "#0d9488",
    tempo: "há 2 semanas",
    estrelas: 5,
    avatar: "/images/avatars/avatar_paula_woman_1794843388593.jpg",
    texto:
      "Em duas semanas minha barriga amanheceu bem mais baixa e parei de sentir aquele estufamento depois do jantar. Continuo tomando todo dia para manter os resultados.",
  },
  {
    nome: "Ricardo A.",
    inicial: "R",
    cor: "#1d4ed8",
    tempo: "há 3 semanas",
    estrelas: 5,
    avatar: "/images/avatars/avatar_ricardo_man_1794843390291.jpg",
    texto:
      "Dissolve em segundos na água e virou hábito aqui em casa. Em 14 dias já senti as pernas mais leves no fim do expediente e a entrega foi super rápida.",
  },
  {
    nome: "Daniela M.",
    inicial: "D",
    cor: "#be185d",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "/images/avatars/avatar_daniela_woman_1794843389600.jpg",
    texto:
      "Sabor bem neutro, não dá peso no estômago e me ajudou a beber muito mais água por dia. O inchaço no rosto pela manhã sumiu.",
  },
  {
    nome: "Gustavo R.",
    inicial: "G",
    cor: "#15803d",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "/images/avatars/avatar_gustavo_man_1794843390876.jpg",
    texto:
      "Peguei o kit recomendado de 3 potes e não me arrependo. Zero retenção nos tornozelos e sigo usando diariamente para não perder o resultado.",
  },
  {
    nome: "Sílvia C.",
    inicial: "S",
    cor: "#7c3aed",
    tempo: "há 2 meses",
    estrelas: 5,
    avatar: "/images/avatars/avatar_silvia_woman_1794843390529.jpg",
    texto:
      "Na minha idade eu achava que era normal acordar com as mãos e os pés inchados. Com o LinfaFlow voltou a leveza que eu não sentia há anos.",
  },
  {
    nome: "Thiago N.",
    inicial: "T",
    cor: "#0369a1",
    tempo: "há 3 semanas",
    estrelas: 5,
    avatar: "/images/avatars/avatar_thiago_man_1794843404226.jpg",
    texto:
      "Produto chegou bem embalado e lacrado. Na segunda semana já deu diferença clara na cintura e no conforto abdominal.",
  },
  {
    nome: "Vanessa F.",
    inicial: "V",
    cor: "#a21caf",
    tempo: "há 1 semana",
    estrelas: 5,
    avatar: "/images/avatars/avatar_vanessa_woman_1794843404530.jpg",
    texto: "",
  },
  {
    nome: "Bruno T.",
    inicial: "B",
    cor: "#1b5e34",
    tempo: "há 2 semanas",
    estrelas: 5,
    avatar: "/images/avatars/avatar_bruno_man_1794843404562.jpg",
    texto: "",
  },
  {
    nome: "Elaine B.",
    inicial: "E",
    cor: "#b45309",
    tempo: "há 3 semanas",
    estrelas: 5,
    avatar: "/images/avatars/avatar_elaine_woman_1794843406332.jpg",
    texto: "",
  },
  {
    nome: "Leandro P.",
    inicial: "L",
    cor: "#0f766e",
    tempo: "há 1 mês",
    estrelas: 5,
    avatar: "/images/avatars/avatar_leandro_man_1794843406233.jpg",
    texto: "",
  },
]

export const CONTATO = {
  telefone: "+55 (49) 99185-3360",
  email: "contato@linfaflow.com.br",
  horario: "Seg a Sex, 09h às 18h",
  razaoSocial: "",
  cnpj: "",
}
